#include<iostream>
#include<conio.h>
#include<fstream>
#include "bill.h"
#include "admin.h"
#include "customer.h"
using namespace std;

main() // main function
{
	Admin a;
	a.menu();
}